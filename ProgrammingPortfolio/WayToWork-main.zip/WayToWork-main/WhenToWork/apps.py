from django.apps import AppConfig


class WhentoworkConfig(AppConfig):
    name = 'WhenToWork'
